#include "main.h"

void simulate(string filename)
{
	return;
}